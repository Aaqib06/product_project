<?php
include('db_config.php');

$name = $_POST['name'];
$description = $_POST['description'];
$quality = $_POST['quality'];
$price = $_POST['price'];

$sql = "INSERT INTO products (name, description, quality,price) VALUES ('$name', '$description', 'quality','$price')";

if ($conn->query($sql) === TRUE) {
  echo 'Product added successfully.';
} else {
  echo 'Error: ' . $sql . '<br>' . $conn->error;
}

$conn->close();
?>
